import React from 'react';
import Card from 'react-bootstrap/Card';
import Tags from './Tags';

const MyCard = ({ imagen, title, descripcion, tagText, tagColor }) => {
  return (
    <Card style={{ width: "18rem" }}>
      <div style={{ width: "100%", height: "100%", objectFit: "contain" }}>
        <img
          src={imagen}
          alt={title}
          style={{ width: "100%", height: "auto", objectFit: "cover" }}
        />
      </div>
      <Card.Body>
        <Card.Title>{title}</Card.Title>
        <Card.Text>{descripcion}</Card.Text>
        <Tags text={tagText} color={tagColor} />
      </Card.Body>
    </Card>
  );
};

export default MyCard;
