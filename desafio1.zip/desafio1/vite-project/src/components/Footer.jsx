import React from 'react';

const Footer = ({ descripcion }) => {
  return (
    <footer className="text-center py-4 mt-5">
      <p>{descripcion}</p>
    </footer>
  );
};

export default Footer;
