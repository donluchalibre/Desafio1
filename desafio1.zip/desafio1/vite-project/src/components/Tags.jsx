import React from 'react';
import Badge from 'react-bootstrap/Badge';

const Tags = ({ text, color }) => {
  return (
    <Badge
      bg={color}
      style={{
        padding: '0.5em 1em',
        fontSize: '1rem',
        borderRadius: '5px',
        textTransform: 'uppercase',
      }}
    >
      {text}
    </Badge>
  );
};

export default Tags;
