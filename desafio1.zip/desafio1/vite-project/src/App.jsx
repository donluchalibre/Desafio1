import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';
import Footer from './components/Footer';
import MyCard from './components/MyCard';

function App() {
  return (
    <>
      <Header title="LuchaDOGres" />

      <div className='contenedor'>
        <MyCard
          imagen="https://i.pinimg.com/736x/ff/53/27/ff5327268454cbb888004c9cf755ebac.jpg"
          title="Atangana"
          descripcion="El luchador más enigmático. Cada ladrido es un grito de guerra, demostrando que la verdadera fuerza viene del corazón y un buen tazón de croquetas."
          tagText="LuchaDog 1"
          tagColor="primary"
        />
        <MyCard
          imagen="https://www.petsworld.in/blog/wp-content/uploads/2014/09/boxer-in-suerman-costume.jpg"
          title="Dogg Ziggler"
          descripcion="Con su capa al viento, este boxer es el héroe del cuadrilátero. ¡Su “Ladra-Rayo” no solo impresiona, sino que emociona a los aficionados!"
          tagText="LuchaDog 2"
          tagColor="warning"
        />
        <MyCard
          imagen="https://i.pinimg.com/originals/8d/c0/3b/8dc03b3be221b420c3ad89065afdf0f4.jpg"
          title="Stone Dog 316"
          descripcion="Este bulldog combina amor y lucha. Su “Sonrisa Atrapante” puede hacer que hasta el rival más feroz se detenga. Ternura y fuerza en un solo paquete."
          tagText="LuchaDog 3"
          tagColor="success"
        />
        <MyCard
          imagen="https://i.pinimg.com/originals/ef/37/bd/ef37bd9e5082ba3fd31e0f73c7d223a9.jpg"
          title="Dog Lesnar"
          descripcion="Pequeño pero valiente, demuestra que el coraje no tiene tamaño. Cada ladrido es un recordatorio de que la lucha es tanto física como emocional."
          tagText="LuchaDog 4"
          tagColor="danger"
        />
        <MyCard
          imagen="https://www.artcollectorz.com/assets/managed/images/cache/AAHQKAAAMIA7IAIAAAAAAYQB6QA7777774AAAAAARIBJOAYA.jpg"
          title="Perrito Mc Mahon"
          descripcion="Este luchador va directo al grano. Con su astucia y garra, sabe que “¡No hay victoria sin esfuerzo!” Su mirada desafiante habla por sí misma."
          tagText="LuchaDog 5"
          tagColor="dark"
        />
        <MyCard
          imagen="https://i.pinimg.com/originals/46/b0/9a/46b09a523f317c2caee2df30c69c6437.jpg"
          title="RK Guau"
          descripcion="Con su disfraz brillante, este perrito es el verdadero espectáculo. Su “Movimiento de Celebración” hace que todos se pongan de pie. ¡Una estrella en todo su esplendor!"
          tagText="LuchaDog 6"
          tagColor="info"
        />
      </div>
      <Footer descripcion="Lucha Libre, ladridos y muchos pelos..." />
    </>
  );
}

export default App;
